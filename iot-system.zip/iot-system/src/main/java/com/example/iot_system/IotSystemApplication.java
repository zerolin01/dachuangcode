package com.example.iot_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IotSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(IotSystemApplication.class, args);
	}

}
